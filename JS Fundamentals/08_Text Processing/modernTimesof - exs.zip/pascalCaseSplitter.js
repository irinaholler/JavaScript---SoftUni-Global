function pascalCaseSplitter(letters) {
    let words = "";
    for (let index = 0; index < letters.length; index++) {
        let elements = letters.charAt(index);
        
        if((elements >= 'A') && (elements <= 'Z')) {
            words += elements;
        }
        
    }
    console.log(words);
}

pascalCaseSplitter('SplitMeIfYouCanHaHaYouCantOrYouCan')