function textProcessing(word) {
    for (const letter of word) {
        console.log(letter);
    }
}

textProcessing('AWord')