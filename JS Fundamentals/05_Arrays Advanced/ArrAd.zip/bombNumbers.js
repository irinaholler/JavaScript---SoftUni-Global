function bombNumbers(sequence, bombNum) {
    let power = bombNum.pop();

    for (let index = 0; index < sequence.length; index++) {
        let element = sequence[index];
            if(element == bombNum) {
                console.log(element);
            }
    }
}

bombNumbers([1, 2, 2, 4, 2, 2, 2, 9],
    [4, 2])
console.log("----------");
bombNumbers([1, 4, 4, 2, 8, 9, 1],
    [9, 3])