function bombNumbers(params) {
    
}

bombNumbers([1, 2, 2, 4, 2, 2, 2, 9],
    [4, 2])
console.log("----------");
bombNumbers([1, 4, 4, 2, 8, 9, 1],
    [9, 3])